import numpy as np
from sklearn.model_selection import StratifiedKFold
import csv
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
import pandas as pd
from collections import Counter
import random
from imblearn.over_sampling import SMOTE


class MyDataServer():
    def __init__(self, file_path, header, names, usecols, uncod_cols, userows):
        data = pd.read_csv(file_path, header=header,
                           names=names, usecols=usecols, encoding='GBK')
        data = data.iloc[userows, :]
        #data = data.iloc[range(0, 20), :]
        data_train, data_test, y_train, y_test = train_test_split(
            data, data.iloc[:, -1], test_size=0.2, random_state=1)
        y_train = y_train.values
        y_test = y_test.values

        x_train, x_test = get_expanding_mean(
            data_train, data_test, usecols[:-1], uncod_cols, usecols[-1])
        # x_train, x_test = get_kfold_mean(
        #   data_train, data_test, usecols[:-1], uncod_cols, usecols[-1])
        # x_train, x_test = get_loo_mean(
        #    data_train, data_test, usecols[:-1], uncod_cols, usecols[-1])
        # x_train, x_test = get_smooth_mean(
        #    data_train, data_test, usecols[:-1], uncod_cols, usecols[-1], m=600)
        # x_train, x_test = beta_target_encoding(
        #   data_train, data_test, usecols[:-1], uncod_cols, usecols[-1])

        #min_max_scaler = preprocessing.MinMaxScaler()
        min_max_scaler = preprocessing.MaxAbsScaler()
        x_train = min_max_scaler.fit_transform(x_train)
        x_test = min_max_scaler.transform(x_test)

        standard_scaler = preprocessing.StandardScaler().fit(x_train)
        x_train = standard_scaler.transform(x_train)
        x_test = standard_scaler.transform(x_test)

        '''
        print(Counter(y_train))
        smo = SMOTE(random_state=42)
        x_train, y_train = smo.fit_sample(x_train, y_train)
        print(Counter(y_train))
        '''

        x_tr, y_tr = [], []
        train_index = range(len(x_train))
        for i in range(20000):
            t = random.choice(train_index)
            x_tr.append(x_train[t])
            y_tr.append(y_train[t])

        self.x_train = x_train
        self.x_test = x_test
        self.y_train = y_train
        self.y_test = y_test
        '''
        self.x_train = x_tr
        self.x_test = x_test
        self.y_train = y_tr
        self.y_test = y_test
        '''


class MyDataSet(Dataset):
    def __init__(self, x, y):
        self.x = torch.FloatTensor(x)
        self.y = torch.LongTensor(y)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, index):
        return self.x[index], self.y[index]


def get_kfold_mean(data_train, data_test, cols, uncod_cols, target, folds=5):
    # https://rearcher.github.io/ml-target-encoding.html
    skf = StratifiedKFold(n_splits=folds, shuffle=True, random_state=918)
    train, test = pd.DataFrame(), pd.DataFrame()
    for col in cols:
        if col in uncod_cols:
            new_col = str(col) + '_' + target
            train[new_col] = data_train[col].values
            test[new_col] = data_test[col].values
            continue
        new_col = str(col) + '_' + target + '_mean'
        train[new_col] = np.zeros(data_train.shape[0])
        test[new_col] = np.zeros(data_test.shape[0])
    for tr_idx, val_idx in skf.split(data_train, data_train[target]):
        X_tr, X_val = data_train.iloc[tr_idx], data_train.iloc[val_idx]
        for col in cols:
            if col in uncod_cols:
                continue
            new_col = col + '_' + target + '_mean'
            gg = X_tr.groupby(col)
            tt = X_tr.groupby(col)[target]
            mm = X_tr.groupby(col)[target].mean()
            tmp_means = X_val[col].map(X_tr.groupby(col)[target].mean())
            train[new_col][val_idx] = tmp_means
    prior = data_train[target].mean()
    for col in cols:
        if col in uncod_cols:
            continue
        new_col = col + '_' + target + '_mean'
        train[new_col].fillna(prior, inplace=True)
        target_map = data_train.groupby(col)[target].mean()
        test[new_col] = data_test[col].map(target_map)
        test[new_col].fillna(prior, inplace=True)
    return train, test
    # return pd.concat([train, test], axis=0).reset_index(drop=True)


def get_loo_mean(data_train, data_test, cols, uncod_cols, target):
    # https://rearcher.github.io/ml-target-encoding.html
    prior = data_train[target].mean()
    train, test = pd.DataFrame(), pd.DataFrame()
    for col in cols:
        if col in uncod_cols:
            new_col = str(col) + '_' + target
            train[new_col] = data_train[col].values
            test[new_col] = data_test[col].values
            continue
        new_col = col + '_' + target + '_mean'
        target_sum = data_train.groupby(col)[target].transform('sum')
        n_objects = data_train.groupby(col)[target].transform('count')
        train[new_col] = (target_sum - data_train[target]) / (n_objects - 1)
        train[new_col].fillna(prior, inplace=True)
        test[new_col] = data_test[col].map(
            data_train.groupby(col)[target].mean())
        test[new_col].fillna(prior, inplace=True)
    return train, test
    # return pd.concat([train, test], axis=0).reset_index(drop=True)


def get_smooth_mean(data_train, data_test, cols, uncod_cols, target, m=300):
    # https://rearcher.github.io/ml-target-encoding.html
    def get_smooth_mean_map(df, by, on, m=300):
        mean = df[on].mean()
        agg = df.groupby(by)[on].agg(['count', 'mean'])
        counts = agg['count']
        means = agg['mean']
        smooth = (counts * means + m * mean) / (counts + m)
        return smooth
    prior = data_train[target].mean()
    train, test = pd.DataFrame(), pd.DataFrame()
    for col in cols:
        if col in uncod_cols:
            new_col = str(col) + '_' + target
            train[new_col] = data_train[col]
            test[new_col] = data_test[col]
            continue
        new_col = col + '_' + target + '_mean'
        target_map = get_smooth_mean_map(data_train, by=col, on=target, m=m)
        train[new_col] = data_train[col].map(target_map)
        test[new_col] = data_test[col].map(target_map).fillna(prior)
    return train, test
    # return pd.concat([train, test], axis=0).reset_index(drop=True)


def get_expanding_mean(data_train, data_test, cols, uncod_cols, target):
    # https://rearcher.github.io/ml-target-encoding.html
    prior = data_train[target].mean()
    train, test = pd.DataFrame(), pd.DataFrame()
    for col in cols:
        if col in uncod_cols:
            new_col = str(col) + '_' + target
            train[new_col] = data_train[col]
            test[new_col] = data_test[col]
            continue
        new_col = str(col) + '_' + target + '_mean'
        cumsum = data_train.groupby(col)[target].cumsum() - data_train[target]
        cumcnt = data_train.groupby(col)[target].cumcount()
        train[new_col] = cumsum / cumcnt
        train[new_col].fillna(prior, inplace=True)
        test[new_col] = data_test[col].map(
            data_train.groupby(col)[target].mean())
        test[new_col].fillna(prior, inplace=True)
    return train, test
    # return pd.concat([train, test], axis=0).reset_index(drop=True)


def likelihood_mean(data_train, data_test, cols, uncod_cols, target):
    # https://mattmotoki.github.io/beta-target-encoding.html
    # https://zhuanlan.zhihu.com/p/40231966
    n_folds = 20
    n_inner_folds = 10
    likelihood_encoded = pd.Series()
    likelihood_coding_map = {}

    oof_default_mean = train[target].mean()  # global prior mean
    kf = KFold(n_splits=n_folds, shuffle=True)
    oof_mean_cv = pd.DataFrame()
    split = 0

    for infold, oof in kf.split(train[feature]):
        print('==============level 1 encoding..., fold %s ============' % split)
        inner_kf = KFold(n_splits=n_inner_folds, shuffle=True)
        inner_oof_default_mean = train.iloc[infold][target].mean()
        inner_split = 0
        inner_oof_mean_cv = pd.DataFrame()

        likelihood_encoded_cv = pd.Series()
        for inner_infold, inner_oof in inner_kf.split(train.iloc[infold]):
            print(
                '==============level 2 encoding..., inner fold %s ============' % inner_split)
            # inner out of fold mean
            oof_mean = train.iloc[inner_infold].groupby(by=feature)[
                target].mean()
            # assign oof_mean to the infold
            likelihood_encoded_cv = likelihood_encoded_cv.append(train.iloc[infold].apply(
                lambda x: oof_mean[x[feature]]
                if x[feature] in oof_mean.index
                else inner_oof_default_mean, axis=1))
            inner_oof_mean_cv = inner_oof_mean_cv.join(
                pd.DataFrame(oof_mean), rsuffix=inner_split, how='outer')
            inner_oof_mean_cv.fillna(inner_oof_default_mean, inplace=True)
            inner_split += 1

        oof_mean_cv = oof_mean_cv.join(pd.DataFrame(
            inner_oof_mean_cv), rsuffix=split, how='outer')
        oof_mean_cv.fillna(value=oof_default_mean, inplace=True)
        split += 1
        print('============final mapping...===========')
        likelihood_encoded = likelihood_encoded.append(train.iloc[oof].apply(
            lambda x: np.mean(inner_oof_mean_cv.loc[x[feature]].values)
            if x[feature] in inner_oof_mean_cv.index
            else oof_default_mean, axis=1))
    # map into test dataframe
    train[feature] = likelihood_encoded
    likelihood_coding_mapping = oof_mean_cv.mean(axis=1)
    default_coding = oof_default_mean

    likelihood_coding_map[feature] = (
        likelihood_coding_mapping, default_coding)
    mapping, default_mean = likelihood_coding_map[feature]
    test[feature] = test.apply(
        lambda x: mapping[x[feature]] if x[feature] in mapping else default_mean, axis=1)


def get_beta_code(data_train, data_test, cols, uncod_cols, target):
    from sklearn.model_selection import KFold
    from BetaEncoder import BetaEncoder
    n_folds = 5
    kf = KFold(n_splits=n_folds, shuffle=True, random_state=0)
    for i, (dev_index, val_index) in enumerate(kf.split(data_train.index.values)):
        dev = data_train.loc[dev_index].reset_index(drop=True)
        val = data_train.loc[val_index].reset_index(drop=True)
        feature_cols = []
        for var_name in cols:
            be = BetaEncoder(var_name)
            be.fit(dev, target)
            feature_name = f'{var_name}_mean'
            dev[feature_name] = be.transform(dev,  'mean', N_min)
            val[feature_name] = be.transform(val,  'mean', N_min)
            feature_cols.append(feature_name)


def beta_target_encoding(train, test, cat_cols, uncod_cols, target_col):
    # https://zhuanlan.zhihu.com/p/40231966
    # train -> training dataframe
    # test -> test dataframe
    # N_min -> smoothing term, minimum sample size, if sample size is less than N_min, add up to N_min
    # target_col -> target column
    # cat_cols -> categorical colums
    # Step 1: fill NA in train and test dataframe

    # Step 2: 5-fold CV (beta target encoding within each fold)
    from sklearn.model_selection import KFold
    kf = KFold(n_splits=5, shuffle=True, random_state=0)
    for i, (dev_index, val_index) in enumerate(kf.split(train.index.values)):
        # split data into dev set and validation set
        dev = train.loc[dev_index].reset_index(drop=True)
        val = train.loc[val_index].reset_index(drop=True)
        feature_cols = []
        for var_name in cat_cols:
            feature_name = f'{var_name}_mean'
            feature_cols.append(feature_name)
            prior_mean = np.mean(dev[target_col])
            stats = dev[[target_col, var_name]].groupby(var_name).agg(['sum', 'count'])[
                target_col].reset_index()

            # beta target encoding by Bayesian average for dev set
            df_stats = pd.merge(dev[[var_name]], stats, how='left')
            df_stats['sum'].fillna(value=prior_mean, inplace=True)
            df_stats['count'].fillna(
                value=1.0, inplace=True)
            # prior parameters
            N_prior = np.maximum(N_min - df_stats['count'].values, 0)
            dev[feature_name] = (prior_mean * N_prior + df_stats['sum']) / \
                (N_prior + df_stats['count'])  # Bayesian mean

            # beta target encoding by Bayesian average for val set
            df_stats = pd.merge(val[[var_name]], stats, how='left')
            df_stats['sum'].fillna(value=prior_mean, inplace=True)
            df_stats['count'].fillna(value=1.0, inplace=True)
            # prior parameters
            N_prior = np.maximum(N_min - df_stats['count'].values, 0)
            val[feature_name] = (prior_mean * N_prior + df_stats['sum']) / \
                (N_prior + df_stats['count'])  # Bayesian mean

            # beta target encoding by Bayesian average for test set
            df_stats = pd.merge(test[[var_name]], stats, how='left')
            df_stats['sum'].fillna(value=prior_mean, inplace=True)
            df_stats['count'].fillna(value=1.0, inplace=True)
            # prior parameters
            N_prior = np.maximum(N_min - df_stats['count'].values, 0)
            test[feature_name] = (prior_mean * N_prior + df_stats['sum']) / \
                (N_prior + df_stats['count'])  # Bayesian mean

            # Bayesian mean is equivalent to adding N_prior data points of value prior_mean to the data set.
            del df_stats, stats
        # Step 3: train model (K-fold CV), get oof prediction
