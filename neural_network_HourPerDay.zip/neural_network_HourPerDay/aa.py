from keras.initializers import RandomUniform
from matplotlib import pyplot
from keras.optimizers import Adam
from keras.callbacks import EarlyStopping
import time
from tensorflow import keras
from collections import Counter
import pandas as pd
import numpy as np
import random
from MyData import MyDataServer, MyDataSet
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

dsvr = MyDataServer('data.csv', header=0, names=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l'],
                    usecols=['b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l'], uncod_cols=['d', 'f', 'g', 'h'], userows=range(0, 3446))
# print(dsvr.x_train.shape[-1])
ki = RandomUniform(minval=0, maxval=0.05)
lys = [
    keras.layers.Input(shape=(dsvr.x_train.shape[-1])),
    keras.layers.Dense(8, activation='relu', use_bias=True,
                       kernel_initializer=ki, bias_initializer='zeros'),
    keras.layers.Dense(8, activation='relu', use_bias=True,
                       kernel_initializer=ki, bias_initializer='zeros'),
    keras.layers.Dense(8, activation='relu', use_bias=True,
                       kernel_initializer=ki, bias_initializer='zeros'),
    #keras.layers.Dense(1, activation='sigmoid'),
    keras.layers.Dense(1),
]
model = keras.Sequential(lys)
model.summary()
check_callback = keras.callbacks.ModelCheckpoint(
    'fraud_model/epoch_{epoch}.h5')
callbacks = [check_callback]

model.compile(loss='mse', optimizer=keras.optimizers.SGD(
    learning_rate=0.0001, momentum=0, nesterov=True), metrics=[['mse']])
tensorboard_callback = keras.callbacks.TensorBoard(
    log_dir='./logs/'+time.strftime('%Y.%m.%d.%H_%M_%S'))
check_callback = keras.callbacks.ModelCheckpoint(
    'fraud_model/epoch_{epoch}.h5')
callbacks = [tensorboard_callback, check_callback]

x_train = dsvr.x_train
y_train = dsvr.y_train  # + np.random.normal(0, 1, (len(dsvr.y_train),))
history = model.fit(
    x_train, y_train, batch_size=128, epochs=200, verbose=2,
    validation_data=(dsvr.x_test, dsvr.y_test), callbacks=callbacks)

y_pred = np.squeeze(model.predict(dsvr.x_train))  # x_test
print(np.average(y_pred))
print(np.average(dsvr.y_train))  # y_test
args = np.argsort(dsvr.y_train)  # y_test
pyplot.plot(dsvr.y_train[args], label='y')  # y_test
# pyplot.plot(np.sort(y_pred[args]), label='y_pred')
pyplot.plot(np.sort(np.round(y_pred[args])), label='y_pred_sort')

rpt = pd.DataFrame()
rpt['train'] = dsvr.y_train[args]
rpt['predict'] = np.sort(y_pred[args])
rpt.to_csv('rs.csv')

#pyplot.plot(np.sort(dsvr.y_test), label='y')
#pyplot.plot(np.sort(y_pred), label='y_pred')
#pyplot.plot(history.history['loss'], label='train')
#pyplot.plot(history.history['val_loss'], label='test')
pyplot.legend()
pyplot.show()

'''
early_stopping = EarlyStopping(monitor='val_loss', patience=50, verbose=2)

metrics = [
    keras.metrics.FalseNegatives(name='fn'),
    keras.metrics.FalsePositives(name='fp'),
    keras.metrics.TrueNegatives(name='tn'),
    keras.metrics.TruePositives(name='tp'),
    keras.metrics.Precision(name='precision'),
    keras.metrics.Recall(name='recall'),
    keras.metrics.AUC(name='auc'), ]

model.compile(
    optimizer=keras.optimizers.Adam(0.001),
    loss=keras.losses.BinaryCrossentropy(),
    metrics=metrics)

tensorboard_callback = keras.callbacks.TensorBoard(
    log_dir='./logs/'+time.strftime('%Y.%m.%d.%H_%M_%S'))
check_callback = keras.callbacks.ModelCheckpoint(
    'fraud_model/epoch_{epoch}.h5')
callbacks = [tensorboard_callback, check_callback]
class_weight = {0: 0.5, 1: 100.0}
model.fit(
    dsvr.x_train,
    dsvr.y_train,
    batch_size=64,
    epochs=200,
    verbose=2,
    callbacks=callbacks,
    validation_data=(dsvr.x_test, dsvr.y_test),
    class_weight=class_weight,)
'''
